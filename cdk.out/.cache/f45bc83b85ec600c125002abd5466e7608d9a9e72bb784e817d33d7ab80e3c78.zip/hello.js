


exports.main = async function (event, context) {
    return {
        statusCode: 200,
        response: "Hello from AWS Lambda"
    }
}